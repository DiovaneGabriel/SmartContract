create table usuario(
id integer(10) not null auto_increment,
nome varchar(50) not null,
email varchar(50) not null,
senha varchar(32) not null,
imagem blob,
situacao int(1) default 1 not null,
constraint usuario_pk primary key (id),
constraint usuario_uk unique (email))