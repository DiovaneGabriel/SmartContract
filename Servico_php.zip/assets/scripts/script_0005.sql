ALTER TABLE `contrato` 
CHANGE COLUMN `hash` `hash_conteudo` CHAR(32) NOT NULL ,
ADD COLUMN `hash_transacao` CHAR(64) NULL AFTER `hash_conteudo`,
ADD COLUMN `hash_contrato` CHAR(40) NULL AFTER `hash_transacao`;