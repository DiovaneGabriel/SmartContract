create table contrato(
id int(10) not null auto_increment,
usuario_id int(10) not null,
situacao int(1) default 0 not null,
conteudo mediumblob,
constraint contrato_pk primary key (id),
constraint contrato_fk foreign key (usuario_id) references usuario (id))