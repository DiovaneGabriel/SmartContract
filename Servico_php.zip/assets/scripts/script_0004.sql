alter table contrato add(
hash char(32) not null)