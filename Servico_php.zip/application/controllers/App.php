<?php
defined ( 'BASEPATH' ) or exit ( 'No direct script access allowed' );
class App extends CI_Controller {
	public function __construct() {
		parent::__construct ();
		$this->load->model ( "usuario_model" );
	}
	public function teste(){
		echo 'x';
	}
	public function get_conteudo_contrato() {
		$this->get_contrato ( true );
	}
	public function get_contrato($conteudo = false) {
		$this->load->model ( "contrato_model" );
		
		$usuario = $this->credenciais ();
		$post = json_decode ( $this->input->raw_input_stream );
		
		$contrato = $this->contrato_model->get_contrato_by_id ( $usuario->id, $post->contrato_id, $conteudo );
		
		if ($contrato) {
			if ($conteudo) {
				$contrato->conteudo = base64_encode ( $contrato->conteudo );
			}
			$this->echo_json ( $contrato );
		} else {
			http_response_code ( 404 );
			die ();
		}
	}
	public function cadastrar_contrato() {
		$this->load->model ( "contrato_model" );
		
		$usuario = $this->credenciais ();
		//$post = json_decode ( $this->input->raw_input_stream );
		$post = json_decode( preg_replace('/[\x00-\x1F\x80-\xFF]/', '', $this->input->raw_input_stream ), true );
		$post = (object) $post;
		
		$contrato = [ ];
		$contrato ['usuario_id'] = $usuario->id;
		$contrato ['situacao'] = 0;
		$contrato ['conteudo'] = base64_decode ( $post->conteudo );
		$contrato ['hash_conteudo'] = md5 ( $contrato ['conteudo'] );
		
		$contrato_id = $this->contrato_model->insert ( $contrato );
		
		$retorno = [ ];
		$retorno ['id'] = $contrato_id;
		$retorno ['usuario_id'] = $usuario->id;
		$retorno ['situacao'] = 0;
		$retorno ['hash'] = $contrato ['hash_conteudo'];
		
		
		$retorno = ( object ) $retorno;
		
		$this->echo_json ( $retorno );
	}
	public function login() {
		$post = json_decode ( $this->input->raw_input_stream );
		
		$usuario = $this->usuario_model->get_usuario_by_email_senha ( $post->email, $post->senha );
		if ($usuario) {
			$usuario = ( array ) $usuario;
			$usuario ['hash'] = null;
			$usuario = ( object ) $usuario;
			
			$usuario->imagem ? $usuario->imagem = base64_encode ( file_get_contents ( $usuario->imagem ) ) : null;
			$usuario->hash = md5 ( md5 ( $usuario->id ) . $usuario->email );
			
			$this->echo_json ( $usuario );
		} else {
			http_response_code ( 404 );
			die ();
		}
	}
	public function cadastrar() {
		$post = json_decode ( $this->input->raw_input_stream );
		
		$usuario = $this->usuario_model->get_usuario_by_email ( $post->email );
		if ($usuario) {
			http_response_code ( 409 );
			die ();
		}
		
		$usuario = [ ];
		$usuario ['nome'] = $post->nome;
		$usuario ['email'] = $post->email;
		$usuario ['senha'] = $post->senha;
		
		$id = $this->usuario_model->insert ( $usuario );
		
		$usuario = $this->usuario_model->get_usuario_by_id ( $id );
		
		$usuario = ( array ) $usuario;
		$usuario ['hash'] = null;
		$usuario = ( object ) $usuario;
		
		$usuario->imagem ? $usuario->imagem = base64_encode ( file_get_contents ( $usuario->imagem ) ) : null;
		$usuario->hash = md5 ( md5 ( $usuario->id ) . $usuario->email );
		
		$this->echo_json ( $usuario );
	}
	private function credenciais() {
		//$post = json_decode ( $this->input->raw_input_stream );
		$post = json_decode( preg_replace('/[\x00-\x1F\x80-\xFF]/', '', $this->input->raw_input_stream ), true );
		$post = (object) $post;
		
		$usuario = $this->usuario_model->get_usuario_by_email_senha ( $post->email, $post->senha );
		if (! $usuario) {
			http_response_code ( 401 );
			die ();
		}
		
		return $usuario;
	}
	private function echo_json($obj) {
		$obj = json_encode ( $obj, JSON_UNESCAPED_UNICODE );
		$obj = str_replace ( "\/", "/", $obj );
		
		die ( $obj );
	}
}
