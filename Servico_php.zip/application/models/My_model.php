<?php
if (! defined ( 'BASEPATH' ))
	exit ( 'No direct script access allowed' );
class My_model extends CI_Model {
	public function __construct() {
		parent::__construct ();
		$sql = "set autocommit = 1;";
		$this->execute_sql ( $sql );
	}
	public function execute_sql($sql) {
		$this->db->reset_query ();
		$return = $this->db->query ( $sql );
		$this->db->flush_cache ();
		
		return $return;
	}
	public function execute_query($sql) {
		$this->db->reset_query ();
		$query = $this->db->query ( $sql );
		$return = false;
		
		if ($this->db->error () ['message']) {
			$error = $this->db->error ();
			$this->db->flush_cache ();
			self::error ( $error );
		} elseif ($query->num_rows () > 0) {
			$return = $query->result ();
		}
		$this->db->flush_cache ();
		
		return $return;
	}
	public function decodeError($show_sql = false) {
		$sql = $this->db->last_query ();
		
		$error = $this->db->error ();
		$this->db->reset_query ();
		$this->db->flush_cache ();
		
		if ($show_sql) {
			dump ( $sql );
		}
		
		if (! (isset ( $error ['code'] ) && $error ['code'] == "00000")) {
			self::error ( $error );
		}
	}
	private function get_pks($table) {
		$this->db->select ( "kcu.table_name" );
		$this->db->select ( "kcu.column_name" );
		$this->db->from ( "information_schema.key_column_usage kcu" );
		$this->db->from ( "information_schema.table_constraints tc" );
		$this->db->where ( "tc.table_name", $table );
		$this->db->where ( "tc.table_schema", $this->db->database );
		$this->db->where ( "lower(tc.constraint_type)", 'primary key' );
		$this->db->where ( "kcu.table_schema", "tc.table_schema", false );
		$this->db->where ( "kcu.table_name", "tc.table_name", false );
		$this->db->where ( "kcu.constraint_name", "tc.constraint_name", false );
		
		return $this->get_result ();
	}
	public function autoriza_exclusao($table, $pk_value, $ignore = false) {
		// $this->db->select("kcu.table_name");
		// $this->db->select("kcu.column_name");
		// $this->db->from("information_schema.key_column_usage kcu");
		// $this->db->from("information_schema.referential_constraints rc");
		// $this->db->where("kcu.constraint_schema", $this->db->database);
		// $this->db->where("kcu.referenced_table_name", $table);
		// $this->db->where("rc.constraint_schema", "kcu.constraint_schema", false);
		// $this->db->where("rc.constraint_name", "kcu.constraint_name", false);
		// if (is_array($ignore)) {
		// $this->db->where_not_in("kcu.table_name", $ignore);
		// }
		
		// $sub_tables = $this->get_result();
		
		// if ($sub_tables) {
		
		// foreach ($sub_tables as $t) {
		// $pks = $this->get_pks($t->table_name);
		
		// if ($pks) {
		// foreach ($pks as $pk) {
		// $this->db->select($pk->column_name);
		// $this->db->from($t->table_name);
		// $this->db->where($t->column_name, $pk_value);
		
		// $sub_pk_values = $this->get_result();
		
		// if ($sub_pk_values) {
		// foreach ($sub_pk_values as $sub_pk_value) {
		// if (! $this->autoriza_exclusao($t->table_name, $sub_pk_value->{$pk->column_name})) {
		// return false;
		// }
		// }
		// }
		// }
		// }
		// }
		$this->db->select ( "kcu.table_name" );
		$this->db->select ( "kcu.column_name" );
		$this->db->from ( "information_schema.key_column_usage kcu" );
		$this->db->from ( "information_schema.referential_constraints rc" );
		$this->db->where ( "kcu.constraint_schema", $this->db->database );
		$this->db->where ( "kcu.referenced_table_name", $table );
		$this->db->where ( "rc.constraint_schema", "kcu.constraint_schema", false );
		$this->db->where ( "rc.constraint_name", "kcu.constraint_name", false );
		$this->db->where ( "upper(rc.delete_rule) != 'CASCADE'", false, false );
		if (is_array ( $ignore )) {
			$this->db->where_not_in ( "kcu.table_name", $ignore );
		}
		
		$tables = $this->get_result ();
		
		if (! $tables) {
			return true;
		}
		
		foreach ( $tables as $table ) {
			
			$this->db->select ( "*" );
			$this->db->from ( $table->table_name );
			$this->db->where ( $table->column_name, $pk_value );
			
			$result = $this->get_result ();
			if (is_array ( $result ) && count ( $result ) > 0) {
				return false;
			}
		}
		// }
		return true;
	}
	public function error($error) {
		$data ['errorCode'] = 500;
		$decodeError = HTTP::decodeError ( $data ['errorCode'] );
		$data ['errorTitle'] = $decodeError ['title'];
		$data ['errorMessage'] = $decodeError ['message'];
		
		$bar = DIRECTORY_SEPARATOR;
		$file = FCPATH . 'assets' . $bar . 'log' . $bar . date ( 'Y_m_d__H_i_s' ) . '.txt';
		
		$myfile = fopen ( $file, "w" ) or die ( "Unable to open file!" );
		// fwrite($myfile, $error['message'] . PHP_EOL . PHP_EOL . $this->db->last_query());
		fwrite ( $myfile, $error ['message'] . PHP_EOL . PHP_EOL . $this->db->last_query () . PHP_EOL . PHP_EOL . json_encode ( debug_backtrace () ) );
		fclose ( $myfile );
		
		if (ENVIRONMENT == "development") {
			echo $error ['message'];
		} else {
			$this->load->view ( 'errors/index', $data );
			// $this->output->set_status_header ( $data ['errorCode']);
			$this->output->_display ();
		}
		die ();
	}
	public function get_empresas_grupo($empresa_id, $all = false, $usuario_id = false) {
		if ($usuario_id) {
			
			$this->db->select ( '*' );
			$this->db->from ( 'usuario' );
			$this->db->where ( 'id', $usuario_id );
			
			$usuario = $this->get_row ();
			
			if ($usuario->nivel_acesso != 'a') {
				$this->db->select ( "*" );
				$this->db->from ( "usuario_empresa" );
				$this->db->where ( "usuario_id", $usuario_id );
				
				$empresas = $this->get_result ();
				
				if ($empresas) {
					$ids = [ ];
					
					foreach ( $empresas as $row ) {
						$ids [] = $row->empresa_pessoa_id;
					}
					$this->db->where_in ( "pg.id", $ids );
				}
			}
		}
		
		$this->db->select ( "pg.id" );
		$this->db->from ( "pessoa pg" );
		$this->db->from ( "size_grupo_pessoa g" );
		$this->db->from ( "pessoa e" );
		$this->db->where ( "e.id", $empresa_id );
		$this->db->where ( "g.id = e.size_grupo_pessoa_id", false, false );
		$this->db->where ( "pg.size_grupo_pessoa_id = g.id", false, false );
		if (! $all) {
			$this->db->where ( "pg.situacao", 1 );
		}
		
		$grupo = [ ];
		
		$empresas = $this->get_result ();
		if ($empresas) {
			foreach ( $empresas as $empresa ) {
				$grupo [] = $empresa->id;
			}
		} else {
			$this->db->select ( 'situacao' );
			$this->db->from ( 'pessoa' );
			$this->db->where ( 'id', $empresa_id );
			
			$empresa = $this->get_row ();
			
			if ($empresa && $empresa->situacao == 1) {
				$grupo [] = $empresa_id;
			}
		}
		
		return $grupo;
	}
	protected function get_row($show_query = false) {
		$query = $this->db->get ();
		$return = false;
		
		if ($this->db->error () ['message']) {
			$error = $this->db->error ();
			$this->db->flush_cache ();
			self::error ( $error );
		} elseif ($query->num_rows () > 0) {
			$return = $query->row ();
		}
		$this->db->flush_cache ();
		if ($show_query) {
			dump ( $this->db->last_query () );
		}
		return $return;
	}
	protected function get_result($show_query = false, $array = false) {
		$query = $this->db->get ();
		$return = false;
		
		if ($this->db->error () ['message']) {
			$error = $this->db->error ();
			$this->db->flush_cache ();
			self::error ( $error );
		} elseif ($query->num_rows () > 0) {
			$return = $array ? $query->result_array () : $query->result ();
		}
		$this->db->flush_cache ();
		if ($show_query) {
			dump ( $this->db->last_query () );
		}
		return $return;
	}
	protected function get_result_array($show_query = false) {
		return $this->get_result ( $show_query, true );
	}
	protected function filter($get_property, $table_property, $like = false) {
		if (isset ( $_GET [$get_property] ) && (is_numeric ( $_GET [$get_property] ) || $_GET [$get_property] != null)) {
			if (! $like) {
				if (is_array ( $_GET [$get_property] )) {
					$this->db->where_in ( $table_property, $_GET [$get_property] );
				} elseif (is_numeric ( $_GET [$get_property] )) {
					$this->db->where ( $table_property, $_GET [$get_property] );
				} else {
					$this->db->where ( "upper(" . $table_property . ")", strtoupper ( $_GET [$get_property] ) );
				}
			} else {
				$this->filter_like ( $get_property, $table_property );
			}
		}
	}
	protected function filter_data($get_property, $table_property, $condicao) {
		if (isset ( $_GET [$get_property] ) && $_GET [$get_property]) {
			$sql = "date(" . $table_property . ") " . $condicao . " '" . date_to_mysql ( $_GET [$get_property] ) . "'";
			$this->db->where ( $sql, false, false );
		}
	}
	protected function filter_like($get_property, $table_property) {
		if (isset ( $_GET [$get_property] ) && $_GET [$get_property]) {
			$sql = "upper(" . $table_property . ") like '%" . anti_injection ( strtoupper ( $_GET [$get_property] ) ) . "%'";
			$this->db->where ( $sql, false, false );
		}
	}
	protected function get_result_countable($count = false, $dump = false) {
		if ($count) {
			return $this->get_row ()->count;
		} else {
			$this->db->limit ( ROWS_PER_PAGE, ROWS_PER_PAGE * (pagina_atual () - 1) );
			return $this->get_result ( $dump );
		}
	}
	public function delete_temp($tabela) {
		$this->db->where ( "session_id", session_id () );
		$this->db->delete ( "_" . $tabela );
		// dump ( $this->db->last_query () );
		$this->decodeError ();
	}
	public function set_autocommit($option) {
		if ($option) {
			$sql = "set autocommit = 1;";
		} else {
			$sql = "set autocommit = 0;";
		}
		$this->execute_sql ( $sql );
	}
	public function commit() {
		$sql = "commit;";
		$this->execute_sql ( $sql );
	}
	public function rollback() {
		$sql = "rollback;";
		$this->execute_sql ( $sql );
	}
	public function getSessao() {
		$this->db->insert ( 'sessao', [ 
				'data' => date ( 'Y-m-d H:i:s' ) 
		] );
		$id = $this->db->insert_id ();
		$this->decodeError ();
		return $id;
	}
	protected function acesso_usuario($modulo_id, $condicao = false, $editar = true) {
		if ($this->session->usuario->nivel_acesso == 'a') {
			$sql_visualizacao = "1 = 1";
			$sql_edicao = "1 as _editavel";
		} else {
			
			if (! $condicao) {
				$condicao = "criador_usuario_id = " . $this->session->usuario->id;
			}
			
			$sql_visualizacao = "1 = 2";
			$sql_edicao = "0 as _editavel";
			
			$modulo = false;
			
			if ($this->permissoes) {
				foreach ( $this->permissoes as $m ) {
					if ($m->size_modulo_id == $modulo_id) {
						$modulo = $m;
						break;
					}
				}
			}
			
			if ($modulo) {
				
				if ($modulo->visualizacao == 1) {
					$sql_visualizacao = $condicao;
				} else if ($modulo->visualizacao == 2) {
					$sql_visualizacao = "1 = 1";
				}
				
				if ($modulo->edicao == 1) {
					$sql_edicao = "(" . $condicao . ") as _editavel";
				} else if ($modulo->edicao == 2) {
					$sql_edicao = "1 as _editavel";
				}
			}
		}
		if ($editar) {
			$this->db->select ( $sql_edicao, false, false );
		}
		$this->db->where ( "(" . $sql_visualizacao . ")", false, false );
	}
	public function get_preferencias($empresa_id = EMPRESA_ID) {
		$this->db->select ( "*" );
		$this->db->from ( "preferencia" );
		$this->db->where ( "empresa_pessoa_id", $empresa_id );
		
		$result = $this->get_row ();
		
		if (! $result) {
			$row = [ ];
			$row ['empresa_pessoa_id'] = $empresa_id;
			
			$this->db->insert ( 'preferencia', $row );
			$this->decodeError ();
			
			return $this->get_preferencias ();
		}
		
		return $result;
	}
	public function update_preferencias($content) {
		$this->db->where ( 'empresa_pessoa_id', EMPRESA_ID );
		$this->db->update ( 'preferencia', $content );
		
		$this->decodeError ();
	}
	protected function get_select() {
		$sql = $this->db->get_compiled_select ();
		$sql = str_replace ( "`", "", $sql );
		
		$this->db->flush_cache ();
		
		return $sql;
	}
	public function get_modulo_by_empresa_id($empresa_id, $modulo_id) {
		$this->db->select ( "*" );
		$this->db->from ( "pessoa_modulo" );
		$this->db->where ( "pessoa_id", $empresa_id );
		$this->db->where ( "size_modulo_id", $modulo_id );
		return $this->get_row ();
	}
}
