<?php
if (! defined ( 'BASEPATH' ))
	exit ( 'No direct script access allowed' );
require_once 'My_model.php';
class Usuario_model extends My_model {
	public function get_usuario_by_email_senha($email, $senha) {
		$this->db->select ( "*" );
		$this->db->from ( "usuario" );
		$this->db->where ( "email", $email );
		$this->db->where ( "senha", $senha );
		
		return $this->get_row ();
	}
	public function get_usuario_by_id($id) {
		$this->db->select ( "*" );
		$this->db->from ( "usuario" );
		$this->db->where ( "id", $id );
		
		return $this->get_row ();
	}
	public function get_usuario_by_email($email) {
		$this->db->select ( "*" );
		$this->db->from ( "usuario" );
		$this->db->where ( "email", $email );
		
		return $this->get_row ();
	}
	public function insert($content) {
		$this->db->insert ( "usuario", $content );
		$id = $this->db->insert_id ();
		$this->decodeError ();
		
		return $id;
	}
}
