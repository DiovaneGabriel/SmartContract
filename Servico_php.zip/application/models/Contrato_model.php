<?php
if (! defined ( 'BASEPATH' ))
	exit ( 'No direct script access allowed' );
require_once 'My_model.php';
class Contrato_model extends My_model {
	public function get_contrato_by_id($usuario_id, $contrato_id, $conteudo = false) {
		if ($conteudo) {
			$this->db->select ( "*" );
		} else {
			$this->db->select ( "id" );
			$this->db->select ( "usuario_id" );
			$this->db->select ( "situacao" );
		}
		$this->db->from ( "contrato" );
		$this->db->where ( "id", $contrato_id );
		$this->db->where ( "usuario_id", $usuario_id );
		
		return $this->get_row ();
	}
	public function insert($content) {
		
		$this->db->insert ( "contrato", $content );
		$id = $this->db->insert_id ();
		$this->decodeError ();
		
		return $id;
	}
}
