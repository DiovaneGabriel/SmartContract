<?php
defined ( 'BASEPATH' ) or exit ( 'No direct script access allowed' );
require_once APPPATH . 'third_party/composer/vendor/autoload.php';

// use PhpOffice\PhpSpreadsheet\Spreadsheet;
// use PhpOffice\PhpSpreadsheet\Writer\Xlsx;

use Web3\Contract;
use Web3\Web3;
class Blockchain {
	public function __construct() {
		$abi = file_get_contents ( FCPATH . "resources" . DS . "contrato.abi" );
		$bytecode = "6060604052604060405190810160405280600b81526020017f68656c6c6f20776f726c6400000000000000000000000000000000000000000081526020015060006000509080519060200190828054600181600116156101000203166002900490600052602060002090601f016020900481019282601f10608a57805160ff191683800117855560b8565b8280016001018555821560b8579182015b8281111560b7578251826000505591602001919060010190609b565b5b50905060df919060c3565b8082111560db576000818150600090555060010160c3565b5090565b50506102b1806100ef6000396000f360606040526000357c0100000000000000000000000000000000000000000000000000000000900480633ef42c9714610047578063b5cbeac5146100c757610042565b610002565b34610002576100596004805050610138565b60405180806020018281038252838181518152602001915080519060200190808383829060006004602084601f0104600302600f01f150905090810190601f1680156100b95780820380516001836020036101000a031916815260200191505b509250505060405180910390f35b34610002576101206004808035906020019082018035906020019191908080601f0160208091040260200160405190810160405280939291908181526020018383808284378201915050505050509090919050506101f4565b60405180821515815260200191505060405180910390f35b602060405190810160405280600081526020015060006000508054600181600116156101000203166002900480601f0160208091040260200160405190810160405280929190818152602001828054600181600116156101000203166002900480156101e55780601f106101ba576101008083540402835291602001916101e5565b820191906000526020600020905b8154815290600101906020018083116101c857829003601f168201915b505050505090506101f1565b90565b60008160006000509080519060200190828054600181600116156101000203166002900490600052602060002090601f016020900481019282601f1061024557805160ff1916838001178555610276565b82800160010185558215610276579182015b82811115610275578251826000505591602001919060010190610257565b5b5090506102a19190610283565b8082111561029d5760008181506000905550600101610283565b5090565b5050600190506102ac565b91905056";
		
		// $web3 = new Web3 ( 'https://ropsten.infura.io/v3/f65ef3a1d23346ccb0eee1733bbe30bf' );
		$web3 = new Web3 ( 'https://mainnet.infura.io/v3/e9b9d59401324d57b8a35a52e74a3396' );
		$contract = new Contract ( $web3->provider, $abi );
		
		$web3->eth->accounts ( function ($err, $accounts) use($contract, $abi) {
			
			
			if ($err === null) {
				if (isset ( $accounts ) && $accounts) {
					$accounts = $accounts;
				} else {
					throw new RuntimeException ( 'Please ensure you have access to web3 json rpc provider.' );
				}
				$fromAccount = $accounts [0];
				$toAccount = $accounts [1];
				// $fromAccount = "7A6DFD610385B20E503353496B500A33B5D1A6329C3796956B31489CB98F06C2";
				// $toAccount = "";
				$contract->bytecode ( $abi )->new ( 1000000, 'Game Token', 1, 'GT', [ 
						'from' => $fromAccount,
						'gas' => '0x200b20' 
				], function ($err, $result) use($contract, $fromAccount, $toAccount) {
					
					if ($err !== null) {
						throw $err;
					}
					if ($result) {
						echo "\nTransaction has made:) id: " . $result . "\n";
					}
					$transactionId = $result;
					$contract->eth->getTransactionReceipt ( $transactionId, function ($err, $transaction) use($contract, $fromAccount, $toAccount) {
						if ($err !== null) {
							throw $err;
						}
						if ($transaction) {
							$contractAddress = $transaction->contractAddress;
							echo "\nTransaction has mind:) block number: " . $transaction->blockNumber . "\n";
							$contract->at ( $contractAddress )->send ( 'transfer', $toAccount, 16, [ 
									'from' => $fromAccount,
									'gas' => '0x200b20' 
							], function ($err, $result) use($contract, $fromAccount, $toAccount) {
								if ($err !== null) {
									throw $err;
								}
								if ($result) {
									echo "\nTransaction has made:) id: " . $result . "\n";
								}
								$transactionId = $result;
								$contract->eth->getTransactionReceipt ( $transactionId, function ($err, $transaction) use($fromAccount, $toAccount) {
									if ($err !== null) {
										throw $err;
									}
									if ($transaction) {
										echo "\nTransaction has mind:) block number: " . $transaction->blockNumber . "\nTransaction dump:\n";
										var_dump ( $transaction );
									}
								} );
							} );
						}
					} );
				} );
			}
		} );
	}
}