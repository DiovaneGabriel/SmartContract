<?php
defined ( 'BASEPATH' ) or exit ( 'No direct script access allowed' );
$autoload ['packages'] = array ();

$autoload ['libraries'] = array ('database');

$autoload ['drivers'] = array ();

$autoload ['helper'] = array (
		'url',
		'utils' 
);

$autoload ['config'] = array ();

$autoload ['language'] = array ();

$autoload ['model'] = array ();
