<?php
defined ( 'BASEPATH' ) or exit ( 'No direct script access allowed' );

$route ['v1'] = 'app';
$route ['v1/(:any)'] = 'app/$1';
$route ['v1/(:any)/(:any)'] = 'app/$1/$2';
$route ['v1/(:any)/(:any)/(:any)'] = 'app/$1/$2/$3';

$route ['default_controller'] = 'welcome';
$route ['404_override'] = '';
$route ['translate_uri_dashes'] = FALSE;
