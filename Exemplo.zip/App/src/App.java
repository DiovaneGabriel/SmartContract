public class App {

	public static void main(String[] args) {

//		Hash transa��o: 0x8132a29d9148991962d349bb5d773a7e024944cd12254e2b3e7868399b47f338
//		Contract: 0x013b6f8134d7accadf9c9d3f13f42ccd9ddedc45

		String url = "https://ropsten.infura.io/v3/f65ef3a1d23346ccb0eee1733bbe30bf";
		String secretKey = "7A6DFD610385B20E503353496B500A33B5D1A6329C3796956B31489CB98F06C2";
		try {

			// deploy do contrato
			Blockchain bc = new Blockchain(url, secretKey);

			bc.sendContract("saudade do que ainda n�o vivemos");
			System.out.println("Hash transa��o: " + bc.getHashTransacao());
			System.out.println("Contract: " + bc.getContrato());
			String contrato = bc.getContrato();

			// load do contrato
			Blockchain bc2 = new Blockchain(url, secretKey);

			System.out.println("Consultando o contrato: " + contrato);
			System.out.println(bc2.getContract(contrato));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
