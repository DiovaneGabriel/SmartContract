package me.diovane.contratosinteligentes;

import androidx.appcompat.app.AppCompatActivity;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.annotation.TargetApi;
import android.app.Activity;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import me.diovane.contratosinteligentes.database.UsuarioDB;
import me.diovane.contratosinteligentes.helper.ContentRequest;
import me.diovane.contratosinteligentes.library.WebClient;
import me.diovane.contratosinteligentes.model.Usuario;

public class CadastroActivity extends AppCompatActivity implements View.OnClickListener {

    private CadastroTask cadastroTask;
    private TextView mNome;
    private AutoCompleteTextView mEmail;
    private EditText mSenha;
    private Button mSalvar;
    private View mForm;
    private View mProgress;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cadastro);

        mNome = findViewById(R.id.cadastro_nome);
        mEmail = findViewById(R.id.cadastro_email);
        mSenha = findViewById(R.id.cadastro_senha);
        mSalvar = findViewById(R.id.cadastro_salvar);
        mForm = findViewById(R.id.cadastro_form);
        mProgress = findViewById(R.id.cadastro_progress);

        mSalvar.setOnClickListener(this);

    }

    @Override
    public void onClick(View v) {
        this.cadastrar();
    }

    private void cadastrar() {

        View focusView = null;
        Boolean cancel = false;
        String email = mEmail.getText().toString();
        String nome = mNome.getText().toString();
        String senha = mSenha.getText().toString();


        if (TextUtils.isEmpty(nome)) {
            mNome.setError(getString(R.string.error_field_required));
            focusView = mNome;
            cancel = true;
        }

        if (TextUtils.isEmpty(email)) {
            mEmail.setError(getString(R.string.error_field_required));
            focusView = mEmail;
            cancel = true;
        } else if (!email.contains("@")) {
            mEmail.setError(getString(R.string.error_invalid_email));
            focusView = mEmail;
            cancel = true;
        }

        if (TextUtils.isEmpty(senha)) {
            mSenha.setError(getString(R.string.error_field_required));
            focusView = mSenha;
            cancel = true;
        }

        if (cancel) {
            focusView.requestFocus();
        } else {
            this.showProgress(true);
            cadastroTask = new CadastroTask(this, nome, email, senha);
            cadastroTask.execute((Void) null);
        }
    }

    @TargetApi(Build.VERSION_CODES.HONEYCOMB_MR2)
    private void showProgress(final boolean show) {
        // On Honeycomb MR2 we have the ViewPropertyAnimator APIs, which allow
        // for very easy animations. If available, use these APIs to fade-in
        // the progress spinner.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB_MR2) {
            int shortAnimTime = getResources().getInteger(android.R.integer.config_shortAnimTime);

            mForm.setVisibility(show ? View.GONE : View.VISIBLE);
            mForm.animate().setDuration(shortAnimTime).alpha(
                    show ? 0 : 1).setListener(new AnimatorListenerAdapter() {
                @Override
                public void onAnimationEnd(Animator animation) {
                    mForm.setVisibility(show ? View.GONE : View.VISIBLE);
                }
            });

            mProgress.setVisibility(show ? View.VISIBLE : View.GONE);
            mProgress.animate().setDuration(shortAnimTime).alpha(
                    show ? 1 : 0).setListener(new AnimatorListenerAdapter() {
                @Override
                public void onAnimationEnd(Animator animation) {
                    mProgress.setVisibility(show ? View.VISIBLE : View.GONE);
                }
            });
        } else {
            // The ViewPropertyAnimator APIs are not available, so simply show
            // and hide the relevant UI components.
            mProgress.setVisibility(show ? View.VISIBLE : View.GONE);
            mForm.setVisibility(show ? View.GONE : View.VISIBLE);
        }
    }


    public class CadastroTask extends AsyncTask<Void, Void, Boolean> {

        private final Activity activity;
        private final String nome;
        private final String email;
        private final String senha;
        private final WebClient wc;

        CadastroTask(Activity activity, String nome, String email, String senha) {
            this.activity = activity;
            this.nome = nome;
            this.email = email;
            this.senha = senha;
            wc = new WebClient(this.activity);
        }

        @Override
        protected Boolean doInBackground(Void... params) {

            this.wc.request("cadastrar", ContentRequest.cadastro(this.nome, this.email, this.senha), WebClient.POST);

            if (wc.getCode() == 200) {
                Usuario usuario = new Usuario(this.wc.getResponse());
                UsuarioDB db = new UsuarioDB(this.activity);
                db.insert(usuario);

                return true;
            } else {
                return false;
            }

        }

        @Override
        protected void onPostExecute(final Boolean success) {
            cadastroTask = null;
            showProgress(false);


            if (success) {
                Intent intentLogin = new Intent(this.activity, LoginActivity.class);
                startActivity(intentLogin);
                Toast.makeText(this.activity, "Usuário cadastrado com sucesso!", Toast.LENGTH_LONG).show();
                finish();
            } else {
                mSenha.setError("Email já cadastrado!");
                mSenha.requestFocus();
            }

        }

        @Override
        protected void onCancelled() {
            cadastroTask = null;
            showProgress(false);
        }
    }
}
