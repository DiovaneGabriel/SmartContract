package me.diovane.contratosinteligentes;

import androidx.appcompat.app.AppCompatActivity;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.annotation.TargetApi;
import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import me.diovane.contratosinteligentes.database.ContratoDB;
import me.diovane.contratosinteligentes.database.UsuarioDB;
import me.diovane.contratosinteligentes.helper.ContentRequest;
import me.diovane.contratosinteligentes.helper.Util;
import me.diovane.contratosinteligentes.library.WebClient;
import me.diovane.contratosinteligentes.model.Contrato;
import me.diovane.contratosinteligentes.model.Usuario;

public class HomeActivity extends AppCompatActivity {

    private static final int READ_REQUEST_CODE = 42;
    private ContratoTask contrato;
    private View mForm;
    private View mProgress;
    private Usuario usuario;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        UsuarioDB usuarioDB = new UsuarioDB(this);
        this.usuario = usuarioDB.getLogado();

        mForm = findViewById(R.id.home_form);
        mProgress = findViewById(R.id.home_progress);
    }


    public void performFileSearch(View v) {

        // ACTION_OPEN_DOCUMENT is the intent to choose a file via the system's file
        // browser.
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);

        // Filter to only show results that can be "opened", such as a
        // file (as opposed to a list of contacts or timezones)
        intent.addCategory(Intent.CATEGORY_OPENABLE);

        // Filter to show only images, using the image MIME data type.
        // If one wanted to search for ogg vorbis files, the type would be "audio/ogg".
        // To search for all documents available via installed storage providers,
        // it would be "*/*".
        intent.setType("*/*");

        startActivityForResult(intent, READ_REQUEST_CODE);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode,
                                 Intent resultData) {

        super.onActivityResult(requestCode, resultCode, resultData);

        // The ACTION_OPEN_DOCUMENT intent was sent with the request code
        // READ_REQUEST_CODE. If the request code seen here doesn't match, it's the
        // response to some other intent, and the code below shouldn't run at all.

        if (requestCode == READ_REQUEST_CODE && resultCode == Activity.RESULT_OK) {
            // The document selected by the user won't be returned in the intent.
            // Instead, a URI to that document will be contained in the return intent
            // provided to this method as a parameter.
            // Pull that URI using resultData.getData().
            Uri uri = null;
            if (resultData != null) {
                uri = resultData.getData();
                Log.i("SC", "Uri: " + uri.toString());
//                showImage(uri);
                this.contrato = new ContratoTask(this, this.usuario, Util.getBytes(this, uri));
                this.contrato.execute((Void) null);

            }
        }
    }

    @TargetApi(Build.VERSION_CODES.HONEYCOMB_MR2)
    private void showProgress(final boolean show) {
        // On Honeycomb MR2 we have the ViewPropertyAnimator APIs, which allow
        // for very easy animations. If available, use these APIs to fade-in
        // the progress spinner.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB_MR2) {
            int shortAnimTime = getResources().getInteger(android.R.integer.config_shortAnimTime);

            mForm.setVisibility(show ? View.GONE : View.VISIBLE);
            mForm.animate().setDuration(shortAnimTime).alpha(
                    show ? 0 : 1).setListener(new AnimatorListenerAdapter() {
                @Override
                public void onAnimationEnd(Animator animation) {
                    mForm.setVisibility(show ? View.GONE : View.VISIBLE);
                }
            });

            mProgress.setVisibility(show ? View.VISIBLE : View.GONE);
            mProgress.animate().setDuration(shortAnimTime).alpha(
                    show ? 1 : 0).setListener(new AnimatorListenerAdapter() {
                @Override
                public void onAnimationEnd(Animator animation) {
                    mProgress.setVisibility(show ? View.VISIBLE : View.GONE);
                }
            });
        } else {
            // The ViewPropertyAnimator APIs are not available, so simply show
            // and hide the relevant UI components.
            mProgress.setVisibility(show ? View.VISIBLE : View.GONE);
            mForm.setVisibility(show ? View.GONE : View.VISIBLE);
        }
    }

    public class ContratoTask extends AsyncTask<Void, Void, Boolean> {

        private final Usuario mUsuario;
        private final byte[] mConteudo;
        private final Activity mActivity;
        private final WebClient wc;
        private final Contrato mContrato;

        ContratoTask(Activity activity, Usuario usuario, byte[] conteudo) {
            mUsuario = usuario;
            mActivity = activity;
            mConteudo = conteudo;
            wc = new WebClient(this.mActivity);

            mContrato = new Contrato();
            mContrato.setConteudo(conteudo);
            mContrato.setUsuarioId(usuario.getId());

            ContratoDB contratoDB = new ContratoDB(activity);
            mContrato.setId(contratoDB.insert(mContrato));

        }

        @Override
        protected Boolean doInBackground(Void... params) {

            this.wc.request("cadastrar_contrato", ContentRequest.cadastro_contrato(this.mUsuario.getEmail(), this.mUsuario.getSenha(), this.mConteudo), WebClient.POST);

            if (wc.getCode() == 200) {
                Contrato contrato = new Contrato(this.wc.getResponse());
                contrato.setIdLocal(mContrato.getIdLocal());

                ContratoDB db = new ContratoDB(this.mActivity);
                db.update(contrato);

                return true;
            } else {
                return false;
            }

        }

        @Override
        protected void onPostExecute(final Boolean success) {
            contrato = null;
            showProgress(false);

            if (success) {
//                Intent intentHome = new Intent(mActivity, HomeActivity.class);
//                startActivity(intentHome);
//                finish();
                Toast.makeText(this.mActivity, "Feito", Toast.LENGTH_LONG).show();
            }
        }

        @Override
        protected void onCancelled() {
            contrato = null;
            showProgress(false);
        }
    }


}
