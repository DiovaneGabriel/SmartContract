package me.diovane.contratosinteligentes.model;

import android.util.Base64;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.Arrays;

public class Usuario {

    private Integer id;
    private String email;
    private String nome;
    private Integer logado;
    private byte[] imagem;
    private String hash;
    private String senha;

    public Usuario() {
    }

    public Usuario(String response) {
        try {
            JSONObject json = new JSONObject(response);

            this.id = json.getInt("id");
            this.email = json.getString("email");
            this.nome = json.getString("nome");
            this.senha = json.getString("senha");
            this.logado = 1;
            this.hash = json.getString("hash");

            String imagem = json.getString("imagem");
            if (!imagem.equalsIgnoreCase("null")) {
                this.imagem = Base64.decode(imagem.getBytes(), Base64.DEFAULT);
            }

        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public byte[] getImagem() {
        return imagem;
    }

    public void setImagem(byte[] imagem) {
        this.imagem = imagem;
    }

    public Integer getLogado() {
        return logado;
    }

    public void setLogado(Integer logado) {
        this.logado = logado;
    }

    public String getHash() {
        return hash;
    }

    public void setHash(String hash) {
        this.hash = hash;
    }

    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }

    @Override
    public String toString() {
        return "Usuario{" +
                "id=" + id +
                ", email='" + email + '\'' +
                ", nome='" + nome + '\'' +
                ", senha='" + senha + '\'' +
                ", logado=" + logado +
                ", hash=" + hash +
                '}';
    }
}
