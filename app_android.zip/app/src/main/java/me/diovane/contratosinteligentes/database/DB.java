package me.diovane.contratosinteligentes.database;


import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DB extends SQLiteOpenHelper {

    private static final int VERSAO_BANCO = 4;
    private static final String NOME_BANCO = "contratos_inteligentes.db";

    public DB(Context ctx) {
        super(ctx, NOME_BANCO, null, VERSAO_BANCO);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        StringBuilder sql = new StringBuilder();
        sql.append("create table usuario(");
        sql.append("id integer not null primary key,");
        sql.append("nome text not null,");
        sql.append("email text not null,");
        sql.append("senha text not null,");
        sql.append("logado integer not null,");
        sql.append("imagem blob,");
        sql.append("hash text not null)");

        db.execSQL(sql.toString());

        sql = new StringBuilder();
        sql.append("create table contrato(");
        sql.append("id_local integer not null primary key,");
        sql.append("id integer,");
        sql.append("usuario_id integer,");
        sql.append("situacao integer,");
        sql.append("conteudo blob,");
        sql.append("hash text)");

        db.execSQL(sql.toString());

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

        db.execSQL("drop table if exists usuario");
        db.execSQL("drop table if exists contrato");
        onCreate(db);

//        switch (oldVersion) {
//            case 1:
//                db.execSQL("ALTER TABLE usuario ADD COLUMN logado integer;");
//        }
    }
}
