package me.diovane.contratosinteligentes.helper;

import android.util.Base64;

import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class ContentRequest {

    public static String login(String email, String senha) {
        return "{\"email\":\"" + email + "\",\"senha\":\"" + Util.md5(senha) + "\"}";
    }

    public static String cadastro_contrato(String email, String senha, byte[] conteudo) {
        return "{\"email\":\"" + email + "\",\"senha\":\"" + senha + "\",\"conteudo\":\"" + Base64.encodeToString(conteudo, Base64.DEFAULT) + "\"}";
    }

    public static String cadastro(String nome, String email, String senha) {
        return "{\"nome\":\"" + nome + "\",\"email\":\"" + email + "\",\"senha\":\"" + Util.md5(senha) + "\"}";
    }
}
