package me.diovane.contratosinteligentes.model;

import org.json.JSONException;
import org.json.JSONObject;

public class Contrato {

    private Integer idLocal;
    private Integer id;
    private Integer usuarioId;
    private Integer situacao;
    private String hash;
    private byte[] conteudo;

    public Contrato() {
        super();
    }

    public Contrato(String response) {
        try {
            JSONObject json = new JSONObject(response);

            this.id = json.getInt("id");
            this.situacao = json.getInt("situacao");
            this.usuarioId = json.getInt("usuario_id");
            this.hash = json.getString("hash");

        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    @Override
    public String toString() {
        return "Contrato{" +
                "id=" + id +
                ", id_local='" + idLocal + '\'' +
                ", situacao=" + situacao +
                ", hash=" + hash +
                '}';
    }

    public Integer getIdLocal() {
        return idLocal;
    }

    public void setIdLocal(Integer idLocal) {
        this.idLocal = idLocal;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getUsuarioId() {
        return usuarioId;
    }

    public void setUsuarioId(Integer usuarioId) {
        this.usuarioId = usuarioId;
    }

    public Integer getSituacao() {
        return situacao;
    }

    public void setSituacao(Integer situacao) {
        this.situacao = situacao;
    }

    public String getHash() {
        return hash;
    }

    public void setHash(String hash) {
        this.hash = hash;
    }

    public byte[] getConteudo() {
        return conteudo;
    }

    public void setConteudo(byte[] conteudo) {
        this.conteudo = conteudo;
    }
}
