package me.diovane.contratosinteligentes.database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import me.diovane.contratosinteligentes.model.Usuario;


public class UsuarioDB extends DB {

    private SQLiteDatabase db;

    public UsuarioDB(Context ctx) {
        super(ctx);
        this.db = this.getReadableDatabase();
    }

    public void insert(Usuario usuario) {

        Usuario usuarioLogado = this.getLogado();
        while (usuarioLogado != null) {
            usuarioLogado.setLogado(0);
            this.update(usuarioLogado);
            usuarioLogado = this.getLogado();
        }

        Usuario sUsuario = this.getById(usuario.getId());
        if (sUsuario == null) {
            ContentValues values = new ContentValues();
            values.put("id", usuario.getId());
            values.put("nome", usuario.getNome());
            values.put("email", usuario.getEmail());
            values.put("logado", 1);
            values.put("imagem", usuario.getImagem());
            values.put("hash", usuario.getHash());
            values.put("senha", usuario.getSenha());
            this.db.insert("usuario", null, values);
        } else {
            usuario.setLogado(1);
            this.update(usuario);
        }
    }

    public void update(Usuario usuario) {
        ContentValues values = new ContentValues();
        values.put("nome", usuario.getNome());
        values.put("email", usuario.getEmail());
        values.put("logado", usuario.getLogado());
        values.put("imagem", usuario.getImagem());
        values.put("hash", usuario.getHash());
        values.put("senha", usuario.getSenha());
        this.db.update("usuario", values, "id=" + usuario.getId(), null);
    }

    public Usuario getById(Integer id) {
        Usuario usuario;
        String[] colunas = {"id", "nome", "email", "logado", "imagem", "hash", "senha"};
        Cursor cursor = this.db.query("usuario", colunas, "id = " + id, null, null, null, null);
        if (cursor.getCount() == 0) {
            cursor.close();
            return null;
        }

        cursor.moveToFirst();
        usuario = new Usuario();
        usuario.setId(cursor.getInt(cursor.getColumnIndex("id")));
        usuario.setNome(cursor.getString(cursor.getColumnIndex("nome")));
        usuario.setEmail(cursor.getString(cursor.getColumnIndex("email")));
        usuario.setLogado(cursor.getInt(cursor.getColumnIndex("logado")));
        usuario.setImagem(cursor.getBlob(cursor.getColumnIndex("imagem")));
        usuario.setHash(cursor.getString(cursor.getColumnIndex("hash")));
        usuario.setSenha(cursor.getString(cursor.getColumnIndex("senha")));
        cursor.close();

        return usuario;
    }

    public Usuario getLogado() {
        Usuario usuario;
        String[] colunas = {"id", "nome", "email", "logado", "imagem", "hash", "senha"};
        Cursor cursor = this.db.query("usuario", colunas, "logado = 1", null, null, null, null);
        if (cursor.getCount() == 0) {
            cursor.close();
            return null;
        }

        cursor.moveToFirst();
        usuario = new Usuario();
        usuario.setId(cursor.getInt(cursor.getColumnIndex("id")));
        usuario.setNome(cursor.getString(cursor.getColumnIndex("nome")));
        usuario.setEmail(cursor.getString(cursor.getColumnIndex("email")));
        usuario.setLogado(cursor.getInt(cursor.getColumnIndex("logado")));
        usuario.setImagem(cursor.getBlob(cursor.getColumnIndex("imagem")));
        usuario.setHash(cursor.getString(cursor.getColumnIndex("hash")));
        usuario.setSenha(cursor.getString(cursor.getColumnIndex("senha")));
        cursor.close();

        return usuario;
    }
}
