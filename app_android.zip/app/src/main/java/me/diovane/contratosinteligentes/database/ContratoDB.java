package me.diovane.contratosinteligentes.database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import me.diovane.contratosinteligentes.model.Contrato;
import me.diovane.contratosinteligentes.model.Usuario;


public class ContratoDB extends DB {

    private SQLiteDatabase db;

    public ContratoDB(Context ctx) {
        super(ctx);
        this.db = this.getReadableDatabase();
    }

    public Integer insert(Contrato contrato) {

            ContentValues values = new ContentValues();
            values.put("id", contrato.getId());
            values.put("usuario_id", contrato.getUsuarioId());
            values.put("situacao", contrato.getSituacao());
            values.put("hash", contrato.getHash());
//            values.put("conteudo", contrato.getConteudo());

            Long l = this.db.insert("contrato", null, values);
            return l.intValue();

    }

    public void update(Contrato contrato) {
        ContentValues values = new ContentValues();
        values.put("situacao", contrato.getSituacao());
        values.put("conteudo", contrato.getConteudo());
        values.put("hash", contrato.getHash());
        this.db.update("contrato", values, "id_local=" + contrato.getIdLocal(), null);
    }

    public Contrato getByIdLocal(Integer IdLocal) {
        Contrato contrato;
        String[] colunas = {"id", "local_id", "usuario_id", "situacao", "conteudo", "hash"};
        Cursor cursor = this.db.query("contrato", colunas, "id_local = " + IdLocal, null, null, null, null);
        if (cursor.getCount() == 0) {
            cursor.close();
            return null;
        }

        cursor.moveToFirst();
        contrato = new Contrato();
        contrato.setId(cursor.getInt(cursor.getColumnIndex("id")));
        contrato.setIdLocal(cursor.getInt(cursor.getColumnIndex("id_local")));
        contrato.setUsuarioId(cursor.getInt(cursor.getColumnIndex("usuario_id")));
        contrato.setSituacao(cursor.getInt(cursor.getColumnIndex("situacao")));
        contrato.setConteudo(cursor.getBlob(cursor.getColumnIndex("conteudo")));
        contrato.setHash(cursor.getString(cursor.getColumnIndex("hash")));
        cursor.close();

        return contrato;
    }


}
