package me.diovane.contratosinteligentes.library;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.util.Log;

import java.io.IOException;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.NoSuchElementException;
import java.util.Scanner;

public class WebClient {

//    private static final String BASE_URL = "http://192.168.3.8/contratos_inteligentes/v1/";
    private static final String BASE_URL = "http://size.ddns.net:1880/contratos_inteligentes/v1/";
    private int code;
    private String response;
    private Context context;

    public WebClient(Context context) {
        this.context = context;
    }

    public static final String GET = "GET";
    public static final String PUT = "PUT";
    public static final String POST = "POST";
    public static final String DELETE = "DELETE";

    public int getCode() {
        return code;
    }

    public String getResponse() {
        return response;
    }


    public void request(String url) {
        request(url, null, GET);
    }

    public void request(String url, String requestType) {
        request(url, null, requestType);
    }

    public void request(String url, String data, String requestType) {

        if (isConnected()) {
            this.code = 0;
            this.response = null;

            String urlString = "";
            try {
                urlString = BASE_URL + url;
                if (requestType.equalsIgnoreCase(GET) && data != null) {
                    urlString += data;
                }

                Log.d("Web Client URL", urlString);

                HttpURLConnection connection = (HttpURLConnection) new URL(urlString).openConnection();
                connection.setRequestMethod(requestType);
                connection.setRequestProperty("Content-Type", "application/json");
                connection.setRequestProperty("Accept", "application/json");
                connection.setRequestProperty("User-Agent", "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.11 (KHTML, like Gecko) Chrome/23.0.1271.95 Safari/537.11");

                if (requestType.equalsIgnoreCase(PUT) || requestType.equalsIgnoreCase(POST)) {
                    connection.setDoOutput(true);
                    OutputStreamWriter osw = new OutputStreamWriter(connection.getOutputStream());
                    Log.d("Web Client data", data);
                    osw.write(data);
                    osw.flush();
                    osw.close();
                }

                Log.d("Web Client Request Type", requestType);
                this.code = connection.getResponseCode();
                Log.d("Web Client Code", String.valueOf(this.code));
                if (this.code == 200) {
                    Scanner scanner = new Scanner(connection.getInputStream());
                    String line = "";

                    try {
                        do {
                            line = scanner.next();
                            if (this.response == null) {
                                this.response = line + " ";
                            } else {
                                this.response += line + " ";
                            }
                        } while (line != null);
                    } catch (NoSuchElementException e) {
                    }
                    scanner.close();
                    connection.disconnect();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }

            if (this.response != null) {
                Log.d("Web Client Response", this.response);
            }
        } else {
            this.code = 404;
            this.response = null;
            Log.d("Web Client Response", "Não está conectado");
        }
    }

    private boolean isConnected() {
        ConnectivityManager cm = (ConnectivityManager) this.context.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo netInfo = cm.getActiveNetworkInfo();
        //should check null because in air plan mode it will be null
        if (netInfo != null && netInfo.isConnected()) {
            return true;
        } else {
            return false;
        }
    }
}
