package me.diovane.contratosinteligentes.helper;

import android.content.Context;
import android.net.Uri;

import java.io.ByteArrayOutputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class Util {
    public static byte[] getBytes(Context context, Uri uri) {
        InputStream iStream = null;
        ByteArrayOutputStream byteBuffer = new ByteArrayOutputStream();
        int bufferSize = 1024;
        try {
            iStream = context.getContentResolver().openInputStream(uri);
            byte[] buffer = new byte[bufferSize];

            int len = 0;
            while ((len = iStream.read(buffer)) != -1) {
                byteBuffer.write(buffer, 0, len);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return byteBuffer.toByteArray();
    }

    public static String md5(String val) {
        try {
            MessageDigest m = MessageDigest.getInstance("MD5");
            m.update(val.getBytes(), 0, val.length());
            return new BigInteger(1, m.digest()).toString(16);
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        }
        return null;
    }
}
