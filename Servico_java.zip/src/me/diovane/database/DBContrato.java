package me.diovane.database;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import android.net.ParseException;
import me.diovane.model.Contrato;

public class DBContrato {
	public static ArrayList<Contrato> getContratosPendentes(Connection db) throws SQLException, ParseException {

		ArrayList<Contrato> contratos = null;
		StringBuilder sql = new StringBuilder();

		sql.append("select id,");
		sql.append("       usuario_id,");
		sql.append("       situacao,");
//		sql.append("       conteudo,");
		sql.append("       hash_conteudo");
		sql.append("  from contrato");
		sql.append(" where situacao = 0");

		PreparedStatement psSql = db.prepareStatement(sql.toString());
		ResultSet qrySql = psSql.executeQuery();
		Contrato contrato = null;

		while (qrySql.next()) {

			if (contratos == null) {
				contratos = new ArrayList<Contrato>();
			}

			contrato = new Contrato();
			contrato.setId(qrySql.getInt("id"));
			contrato.setUsuarioId(qrySql.getInt("usuario_id"));
			contrato.setSituacao(qrySql.getInt("situacao"));
//			contrato.setConteudo(qrySql.getBytes("conteudo"));
			contrato.setHashConteudo(qrySql.getString("hash_conteudo"));

			contratos.add(contrato);

		}

		psSql.close();
		qrySql.close();

		return contratos;

	}

	public static void updateById(Connection db, Contrato contrato, Integer id) throws SQLException {

		StringBuilder ddl = new StringBuilder();
		ddl.append("update contrato");
		ddl.append("   set situacao = ?,");
		ddl.append("       hash_transacao = ?,");
		ddl.append("       hash_contrato = ?");
		ddl.append(" where id = ?");

		PreparedStatement psDdl = db.prepareStatement(ddl.toString());
		psDdl.setInt(1, contrato.getSituacao());
		psDdl.setString(2, contrato.getHashTransacao());
		psDdl.setString(3, contrato.getHashContrato());
		psDdl.setInt(4, id);

		psDdl.execute();
		psDdl.close();

	}

	// private static ArrayList<EmailAnexo> getAnexosByEmailId(Connection db,
	// Integer id) throws SQLException {
	// ArrayList<EmailAnexo> anexos = null;
	//
	// StringBuilder sql = new StringBuilder();
	// sql.append("select diretorio");
	// sql.append(" from email_anexo");
	// sql.append(" where email_id = ?");
	//
	// PreparedStatement psSql = db.prepareStatement(sql.toString());
	// psSql.setInt(1, id);
	//
	// ResultSet qrySql = psSql.executeQuery();
	// EmailAnexo anexo = null;
	//
	// while (qrySql.next()) {
	//
	// if (anexos == null) {
	// anexos = new ArrayList<EmailAnexo>();
	// }
	//
	// anexo = new EmailAnexo(qrySql.getString("diretorio"));
	// anexos.add(anexo);
	//
	// }
	//
	// psSql.close();
	// qrySql.close();
	//
	// return anexos;
	// }
	//
	// private static ArrayList<EmailParametro>
	// getParametrosByEmailId(Connection db, Integer id) throws SQLException {
	//
	// ArrayList<EmailParametro> parametros = null;
	//
	// StringBuilder sql = new StringBuilder();
	// sql.append("select chave,");
	// sql.append(" valor");
	// sql.append(" from email_parametro");
	// sql.append(" where email_id = ?");
	//
	// PreparedStatement psSql = db.prepareStatement(sql.toString());
	// psSql.setInt(1, id);
	//
	// ResultSet qrySql = psSql.executeQuery();
	// EmailParametro parametro = null;
	//
	// while (qrySql.next()) {
	//
	// if (parametros == null) {
	// parametros = new ArrayList<EmailParametro>();
	// }
	//
	// parametro = new EmailParametro(qrySql.getString("chave"),
	// qrySql.getString("valor"));
	// parametros.add(parametro);
	//
	// }
	//
	// psSql.close();
	// qrySql.close();
	//
	// return parametros;
	//
	// }
	//
	// public static void updateById(Connection db, Email email, Integer id)
	// throws SQLException {
	//
	// StringBuilder ddl = new StringBuilder();
	// ddl.append("update email");
	// ddl.append(" set data_hora_solicitacao = ?,");
	// ddl.append(" email_emitente = ?,");
	// ddl.append(" senha_email_emitente = ?,");
	// ddl.append(" smtp_email_emitente = ?,");
	// ddl.append(" porta_email_emitente = ?,");
	// ddl.append(" label_email_emitente = ?,");
	// ddl.append(" email_destinatario = ?,");
	// ddl.append(" assunto = ?,");
	// ddl.append(" template = ?,");
	// ddl.append(" situacao = ?,");
	// ddl.append(" data_hora_emissao = ?,");
	// ddl.append(" mensagem_erro = ?,");
	// ddl.append(" responder_para = ?,");
	// ddl.append(" com_copia = ?");
	// ddl.append(" where id = ?");
	//
	// PreparedStatement psDdl = db.prepareStatement(ddl.toString());
	// psDdl.setString(1, Util.dateToStr(email.getDataHoraSolicitacao()));
	// psDdl.setString(2, email.getEmailEmitente());
	// psDdl.setString(3, email.getSenhaEmailEmitente());
	// psDdl.setString(4, email.getSmtpEmailEmitente());
	// psDdl.setInt(5, email.getPortaEmailEmitente());
	// psDdl.setString(6, email.getLabelEmailEmitente());
	// psDdl.setString(7, email.getEmailDestinatario());
	// psDdl.setString(8, email.getAssunto());
	// psDdl.setString(9, email.getTemplate());
	// psDdl.setInt(10, email.getSituacao());
	// psDdl.setString(11, Util.dateToStr(email.getDataHoraEmissao()));
	// psDdl.setString(12, email.getMensagemErro());
	// psDdl.setString(13, email.getResponderPara());
	// psDdl.setString(14, email.getComCopia());
	// psDdl.setInt(15, email.getId());
	//
	// psDdl.execute();
	// psDdl.close();
	//
	// }
}
