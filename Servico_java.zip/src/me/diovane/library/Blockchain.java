package me.diovane.library;

import java.math.BigInteger;
import java.util.concurrent.ExecutionException;

import org.web3j.crypto.Credentials;
import org.web3j.protocol.Web3j;
import org.web3j.protocol.core.methods.response.TransactionReceipt;
import org.web3j.protocol.http.HttpService;

public class Blockchain {

	private Web3j web3;
	private Credentials credentials;
	private TransactionReceipt transactionReceipt;

	public Blockchain(String url, String secretKey) throws InterruptedException, ExecutionException {
		super();

		this.web3 = Web3j.build(new HttpService(url));
		this.credentials = Credentials.create(secretKey.toLowerCase());

	}

	public void sendContract(String content) throws Exception {

		SmartContract sc = SmartContract
				.deploy(web3, this.credentials, new BigInteger("1000000"), new BigInteger("3000000")).send();

		this.transactionReceipt = sc.setValor(content).send();

	}

	public String getContract(String contract) throws Exception {

		SmartContract sc = SmartContract.load(contract, this.web3, this.credentials, new BigInteger("5000"),
				new BigInteger("300000"));

		String result = sc.getValor().send();

		return result;

	}

	public String getHashTransacao() {
		return this.transactionReceipt == null ? null : this.transactionReceipt.getTransactionHash();
	}

	public String getContrato() {
		return this.transactionReceipt == null ? null : this.transactionReceipt.getTo();
	}

	public TransactionReceipt getTransactionReceipt() {
		return this.transactionReceipt;
	}

	private void destroy() {
		this.web3.shutdown();
	}

}
