package me.diovane.library;

import java.math.BigInteger;
import java.util.Arrays;
import java.util.Collections;

import org.web3j.abi.TypeReference;
import org.web3j.abi.datatypes.Function;
import org.web3j.abi.datatypes.Type;
import org.web3j.abi.datatypes.Utf8String;
import org.web3j.crypto.Credentials;
import org.web3j.protocol.Web3j;
import org.web3j.protocol.core.RemoteCall;
import org.web3j.protocol.core.methods.response.TransactionReceipt;
import org.web3j.tx.Contract;
import org.web3j.tx.TransactionManager;
import org.web3j.tx.gas.ContractGasProvider;

public class SmartContract extends Contract {
	private static final String BINARY = "6060604052604060405190810160405280600b81526020017f68656c6c6f20776f726c6400000000000000000000000000000000000000000081526020015060006000509080519060200190828054600181600116156101000203166002900490600052602060002090601f016020900481019282601f10608a57805160ff191683800117855560b8565b8280016001018555821560b8579182015b8281111560b7578251826000505591602001919060010190609b565b5b50905060df919060c3565b8082111560db576000818150600090555060010160c3565b5090565b50506102b1806100ef6000396000f360606040526000357c0100000000000000000000000000000000000000000000000000000000900480633ef42c9714610047578063b5cbeac5146100c757610042565b610002565b34610002576100596004805050610138565b60405180806020018281038252838181518152602001915080519060200190808383829060006004602084601f0104600302600f01f150905090810190601f1680156100b95780820380516001836020036101000a031916815260200191505b509250505060405180910390f35b34610002576101206004808035906020019082018035906020019191908080601f0160208091040260200160405190810160405280939291908181526020018383808284378201915050505050509090919050506101f4565b60405180821515815260200191505060405180910390f35b602060405190810160405280600081526020015060006000508054600181600116156101000203166002900480601f0160208091040260200160405190810160405280929190818152602001828054600181600116156101000203166002900480156101e55780601f106101ba576101008083540402835291602001916101e5565b820191906000526020600020905b8154815290600101906020018083116101c857829003601f168201915b505050505090506101f1565b90565b60008160006000509080519060200190828054600181600116156101000203166002900490600052602060002090601f016020900481019282601f1061024557805160ff1916838001178555610276565b82800160010185558215610276579182015b82811115610275578251826000505591602001919060010190610257565b5b5090506102a19190610283565b8082111561029d5760008181506000905550600101610283565b5090565b5050600190506102ac565b91905056";

	public static final String FUNC_GETVALOR = "getValor";

	public static final String FUNC_SETVALOR = "setValor";

	@Deprecated
	protected SmartContract(String contractAddress, Web3j web3j, Credentials credentials, BigInteger gasPrice,
			BigInteger gasLimit) {
		super(BINARY, contractAddress, web3j, credentials, gasPrice, gasLimit);

	}

	@Deprecated
	protected SmartContract(String contractAddress, Web3j web3j, TransactionManager transactionManager,
			BigInteger gasPrice, BigInteger gasLimit) {
		super(BINARY, contractAddress, web3j, transactionManager, gasPrice, gasLimit);
	}

	protected SmartContract(String contractAddress, Web3j web3j, TransactionManager transactionManager,
			ContractGasProvider contractGasProvider) {
		super(BINARY, contractAddress, web3j, transactionManager, contractGasProvider);
	}

	public RemoteCall<TransactionReceipt> setValor(String a) {
		final Function function = new Function(FUNC_SETVALOR,
				Arrays.<Type>asList(new org.web3j.abi.datatypes.Utf8String(a)),
				Collections.<TypeReference<?>>emptyList());
		return executeRemoteCallTransaction(function);
	}

	public RemoteCall<String> getValor() {
		final Function function = new Function(FUNC_GETVALOR, Arrays.<Type>asList(),
				Arrays.<TypeReference<?>>asList(new TypeReference<Utf8String>() {
				}));
		return executeRemoteCallSingleValueReturn(function, String.class);
	}

	@Deprecated
	public static SmartContract load(String contractAddress, Web3j web3j, Credentials credentials, BigInteger gasPrice,
			BigInteger gasLimit) {
		return new SmartContract(contractAddress, web3j, credentials, gasPrice, gasLimit);
	}

	@Deprecated
	public static SmartContract load(String contractAddress, Web3j web3j, TransactionManager transactionManager,
			BigInteger gasPrice, BigInteger gasLimit) {
		return new SmartContract(contractAddress, web3j, transactionManager, gasPrice, gasLimit);
	}

	@Deprecated
	public static RemoteCall<SmartContract> deploy(Web3j web3j, Credentials credentials, BigInteger gasPrice,
			BigInteger gasLimit) {
		return deployRemoteCall(SmartContract.class, web3j, credentials, gasPrice, gasLimit, BINARY, "");
	}

	@Deprecated
	public static RemoteCall<SmartContract> deploy(Web3j web3j, TransactionManager transactionManager,
			BigInteger gasPrice, BigInteger gasLimit) {
		return deployRemoteCall(SmartContract.class, web3j, transactionManager, gasPrice, gasLimit, BINARY, "");
	}

	public static SmartContract load(String contractAddress, Web3j web3j, TransactionManager transactionManager,
			ContractGasProvider contractGasProvider) {
		return new SmartContract(contractAddress, web3j, transactionManager, contractGasProvider);
	}
}
