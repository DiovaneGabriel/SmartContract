package me.diovane.library;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class MySQLConnection {

	public static String status = "N�o conectou...";

	public MySQLConnection() {

	}

	public static java.sql.Connection getConexaoMySQL(String server) throws ClassNotFoundException, SQLException {

		Connection connection = null;

		String driverName = "com.mysql.jdbc.Driver";

		Class.forName(driverName);

		String serverName = server;

		String mydatabase = "contratos_inteligentes";
		String username = "saas";
		String password = "";
		String url = "jdbc:mysql://" + serverName + "/" + mydatabase;

		connection = DriverManager.getConnection(url, username, password);

		if (connection != null) {

			status = ("STATUS--->Conectado com sucesso!");

		} else {

			status = ("STATUS--->N�o foi possivel realizar conex�o");

		}

		return connection;

	}

	public static String statusConection() {

		return status;

	}

}