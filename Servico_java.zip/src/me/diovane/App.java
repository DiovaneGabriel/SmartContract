package me.diovane;

import java.sql.Connection;
import java.util.ArrayList;

import me.diovane.database.DBContrato;
import me.diovane.library.MySQLConnection;
import me.diovane.model.Contrato;

public class App {

	public static void main(String[] args) {

		Connection db = null;
		String server = "192.168.0.100";
		try {
			db = MySQLConnection.getConexaoMySQL(server);
		} catch (Exception e) {
			server = "127.0.0.1";
			try {
				db = MySQLConnection.getConexaoMySQL(server);
			} catch (Exception e1) {
				e1.printStackTrace();
			}
		}

		try {

			ArrayList<Contrato> contratos = null;
			while (true) {
				contratos = DBContrato.getContratosPendentes(db);
				if (contratos != null) {
					for (Contrato contrato : contratos) {
						if (contrato.enviar()) {
							DBContrato.updateById(db, contrato, contrato.getId());
						}
					}
				}

				Thread.sleep(1000);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
