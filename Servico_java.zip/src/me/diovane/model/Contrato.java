package me.diovane.model;

import java.io.IOException;
import java.util.concurrent.ExecutionException;

import me.diovane.library.Blockchain;

public class Contrato {

	private Integer id;
	private Integer usuarioId;
	private Integer situacao;
	private String hashConteudo;
	private String hashTransacao;
	private String hashContrato;
	private byte[] conteudo;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getUsuarioId() {
		return usuarioId;
	}

	public void setUsuarioId(Integer usuarioId) {
		this.usuarioId = usuarioId;
	}

	public Integer getSituacao() {
		return situacao;
	}

	public void setSituacao(Integer situacao) {
		this.situacao = situacao;
	}

	public byte[] getConteudo() {
		return conteudo;
	}

	public void setConteudo(byte[] conteudo) {
		this.conteudo = conteudo;
	}

	public String getHashConteudo() {
		return hashConteudo;
	}

	public void setHashConteudo(String hash) {
		this.hashConteudo = hash;
	}

	public String getHashTransacao() {
		return hashTransacao;
	}

	public void setHashTransacao(String hashTransacao) {
		this.hashTransacao = hashTransacao;
	}

	public String getHashContrato() {
		return hashContrato;
	}

	public void setHashContrato(String hashContrato) {
		this.hashContrato = hashContrato;
	}

	public Boolean enviar() throws InterruptedException, ExecutionException, IOException {
		String url = "https://ropsten.infura.io/v3/f65ef3a1d23346ccb0eee1733bbe30bf";
		String secretKey = "7A6DFD610385B20E503353496B500A33B5D1A6329C3796956B31489CB98F06C2";

		try {

			// deploy do contrato
			Blockchain bc = new Blockchain(url, secretKey);

			System.out.println("enviando contrato...");
//			bc.sendContract(Base64.getEncoder().encodeToString(this.conteudo));
			bc.sendContract(this.hashConteudo);

			this.hashTransacao = bc.getHashTransacao().substring(2);
			this.hashContrato = bc.getContrato().substring(2);
			this.situacao = 9;

			System.out.println("Hash transa��o: " + bc.getHashTransacao());
			System.out.println("Contract: " + bc.getContrato());

			return true;
		} catch (Exception e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
		}
		return false;
	}

}
